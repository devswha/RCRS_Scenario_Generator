package rescuecore2.messages;

/**
   A tagging interface for Messages that are control messages, e.g. handshake and update messages.
 */
public interface Control extends Message {
}
