package gis2.scenario;

/**
   Exception for indicating the the user has cancelled an operation.
*/
public class CancelledByUserException extends Exception {
    /**
       Constructor.
    */
    public CancelledByUserException() {}
}